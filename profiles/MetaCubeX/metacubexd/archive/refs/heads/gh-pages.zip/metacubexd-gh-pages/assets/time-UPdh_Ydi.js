import{V as a,b3 as m}from"./index-CDW6MRp6.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
